# Raylib pipipoppo

I am no idea what me doing.

Tested on [physicsclassroom](https://www.physicsclassroom.com/Physics-Interactives/Light-and-Color/Color-Filters/Color-Filters-Interactive) website for correct colors.

## **Credits:**

Using:

- [Box2D](https://github.com/erincatto/box2d/releases/tag/v2.4.1) by Erin Catto
- [ImGui](https://github.com/ocornut/imgui) by Omar Cornut
- [Raylib](https://github.com/raysan5/raylib) by Ramon Santamaria
- [rlImGui](https://github.com/raylib-extras/rlImGui) by Jeffery Myers
- [stb](https://github.com/nothings/stb) by Sean Barrett

## **Build:**

Linux:
```sh
make
```
